"use client"

import { createUser, createAppointment } from "./data"

// Function to create demo data
export const createDemoData = () => {
  // Create demo patient
  const demoPatient = createUser({
    name: "Demo Patient",
    email: "patient@demo.com",
    password: "password123",
    phone: "555-0123",
    role: "patient",
  })

  // Create some demo appointments
  const today = new Date()
  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)

  const nextWeek = new Date(today)
  nextWeek.setDate(nextWeek.getDate() + 7)

  const lastWeek = new Date(today)
  lastWeek.setDate(lastWeek.getDate() - 7)

  // Upcoming appointment
  createAppointment({
    patientId: demoPatient.id,
    doctorId: "1", // Dr. John Smith - Cardiology
    appointmentDate: tomorrow.toISOString().split("T")[0],
    appointmentTime: "10:00",
    symptoms:
      "Experiencing chest pain and shortness of breath during physical activity. Would like to get a cardiac evaluation.",
    status: "scheduled",
  })

  // Another upcoming appointment
  createAppointment({
    patientId: demoPatient.id,
    doctorId: "4", // Dr. Emily Davis - Pediatrics
    appointmentDate: nextWeek.toISOString().split("T")[0],
    appointmentTime: "14:30",
    symptoms: "Regular checkup for my child. Need to discuss vaccination schedule and growth development.",
    status: "scheduled",
  })

  // Completed appointment
  createAppointment({
    patientId: demoPatient.id,
    doctorId: "2", // Dr. Sarah Johnson - Dermatology
    appointmentDate: lastWeek.toISOString().split("T")[0],
    appointmentTime: "11:00",
    symptoms: "Skin rash on arms and legs that has been persistent for 2 weeks. Itchy and red patches.",
    status: "completed",
    diagnosis: "Eczema (Atopic Dermatitis)",
    prescription: "Hydrocortisone cream 1% - Apply twice daily to affected areas",
    notes:
      "Patient advised to avoid harsh soaps and use fragrance-free moisturizers. Follow up in 2 weeks if symptoms persist.",
  })

  console.log("Demo data created successfully!")
}

// Auto-create demo data when this module is imported
if (typeof window !== "undefined") {
  // Only run in browser
  setTimeout(() => {
    createDemoData()
  }, 100)
}
