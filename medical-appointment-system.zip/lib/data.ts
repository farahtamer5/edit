export interface User {
  id: string
  name: string
  email: string
  password: string
  phone: string
  role: "patient" | "doctor"
  createdAt: Date
}

export interface Doctor {
  id: string
  name: string
  specialization: string
  experienceYears: number
  consultationFee: number
  availableDays: string[]
  availableHours: string
  qualification: string
}

export interface Appointment {
  id: string
  patientId: string
  doctorId: string
  appointmentDate: string
  appointmentTime: string
  status: "scheduled" | "completed" | "cancelled"
  symptoms: string
  diagnosis?: string
  prescription?: string
  notes?: string
  createdAt: Date
}

export const timeSlots = [
  "9:00 AM",
  "9:30 AM",
  "10:00 AM",
  "10:30 AM",
  "11:00 AM",
  "11:30 AM",
  "12:00 PM",
  "12:30 PM",
  "1:00 PM",
  "1:30 PM",
  "2:00 PM",
  "2:30 PM",
  "3:00 PM",
  "3:30 PM",
  "4:00 PM",
  "4:30 PM",
  "5:00 PM",
]

export const formatDate = (dateString: string) => {
  const date = new Date(dateString)
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  })
}

export const formatTime = (timeString: string) => {
  return timeString
}

// Sample data for demo
export const sampleDoctors: Doctor[] = [
  {
    id: "doc-1",
    name: "Sarah Johnson",
    specialization: "Cardiology",
    experienceYears: 15,
    consultationFee: 150,
    availableDays: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    availableHours: "9:00 AM - 5:00 PM",
    qualification: "MD, FACC - Harvard Medical School",
  },
  {
    id: "doc-2",
    name: "Michael Chen",
    specialization: "Dermatology",
    experienceYears: 12,
    consultationFee: 120,
    availableDays: ["Monday", "Wednesday", "Friday"],
    availableHours: "10:00 AM - 4:00 PM",
    qualification: "MD, Dermatology - Johns Hopkins",
  },
  {
    id: "doc-3",
    name: "Emily Rodriguez",
    specialization: "Pediatrics",
    experienceYears: 8,
    consultationFee: 100,
    availableDays: ["Tuesday", "Thursday", "Saturday"],
    availableHours: "8:00 AM - 6:00 PM",
    qualification: "MD, Pediatrics - Stanford Medical",
  },
  {
    id: "doc-4",
    name: "David Wilson",
    specialization: "Orthopedics",
    experienceYears: 20,
    consultationFee: 180,
    availableDays: ["Monday", "Tuesday", "Thursday", "Friday"],
    availableHours: "9:00 AM - 3:00 PM",
    qualification: "MD, Orthopedic Surgery - Mayo Clinic",
  },
]
