# 🚀 MongoDB Deployment Guide - Medical Appointment Booking System

## MongoDB Cloud Database Setup

### Option 1: MongoDB Atlas (Recommended)

#### 1. Create MongoDB Atlas Account
- Go to [mongodb.com/atlas](https://www.mongodb.com/atlas)
- Sign up for free account
- Create a new cluster (M0 Sandbox - Free)

#### 2. Configure Database Access
- Go to Database Access → Add New Database User
- Create username and password
- Set privileges to "Read and write to any database"

#### 3. Configure Network Access
- Go to Network Access → Add IP Address
- Add `0.0.0.0/0` for development (allow access from anywhere)
- For production, add specific IP addresses

#### 4. Get Connection String
- Go to Clusters → Connect → Connect your application
- Choose "Node.js" and version "4.1 or later"
- Copy the connection string
- Replace `<password>` with your database user password
- Replace `<dbname>` with `medical_booking`

Example connection string:
\`\`\`
mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/medical_booking?retryWrites=true&w=majority
\`\`\`

### Option 2: Railway MongoDB

#### 1. Create Railway Account
- Go to [railway.app](https://railway.app)
- Sign up with GitHub

#### 2. Create New Project
- Click "New Project"
- Select "Provision MongoDB"
- Get connection details from Variables tab

### Option 3: Local MongoDB

#### 1. Install MongoDB
\`\`\`bash
# macOS
brew install mongodb-community

# Ubuntu
sudo apt-get install mongodb

# Windows
# Download from mongodb.com
\`\`\`

#### 2. Start MongoDB
\`\`\`bash
# macOS/Linux
mongod

# Windows
net start MongoDB
\`\`\`

#### 3. Connection String
\`\`\`
mongodb://localhost:27017/medical_booking
\`\`\`

## Vercel Deployment with MongoDB

### 1. Environment Variables

In Vercel Dashboard → Project → Settings → Environment Variables:

\`\`\`
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/medical_booking?retryWrites=true&w=majority
JWT_SECRET=your-super-secret-jwt-key-minimum-32-characters
CORS_ORIGIN=https://your-app.vercel.app
NODE_ENV=production
\`\`\`

### 2. Deploy to Vercel

\`\`\`bash
# Install Vercel CLI
npm install -g vercel

# Login
vercel login

# Deploy
vercel --prod
\`\`\`

### 3. Initialize Database

After deployment, initialize your database:

\`\`\`bash
# Set environment variables locally
export MONGODB_URI="your-mongodb-connection-string"

# Run initialization script
node scripts/init-mongo-db.js
\`\`\`

## MongoDB Schema Structure

### Users Collection
\`\`\`javascript
{
  _id: ObjectId,
  name: String,
  email: String (unique),
  password: String (hashed),
  phone: String,
  role: String (enum: 'patient', 'doctor', 'admin'),
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

### Doctors Collection
\`\`\`javascript
{
  _id: ObjectId,
  name: String,
  specialization: String,
  email: String (unique),
  phone: String,
  availableDays: Array of Strings,
  availableHours: String,
  consultationFee: Number,
  experienceYears: Number,
  qualification: String,
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

### Appointments Collection
\`\`\`javascript
{
  _id: ObjectId,
  patientId: ObjectId (ref: users),
  doctorId: ObjectId (ref: doctors),
  appointmentDate: String (YYYY-MM-DD),
  appointmentTime: String (HH:MM),
  status: String (enum: 'scheduled', 'completed', 'cancelled'),
  symptoms: String,
  diagnosis: String,
  prescription: String,
  notes: String,
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

## Database Indexes

### Automatic Indexes Created:
- `users.email` (unique)
- `users.role`
- `doctors.email` (unique)
- `doctors.specialization`
- `appointments.patientId`
- `appointments.doctorId`
- `appointments.appointmentDate`
- `appointments.status`
- Compound index: `{doctorId, appointmentDate, appointmentTime}` (unique, partial)

## Performance Optimization

### 1. Connection Pooling
MongoDB driver automatically handles connection pooling in serverless environments.

### 2. Aggregation Pipelines
Used for complex queries like joining appointments with doctor information.

### 3. Indexes
Proper indexing ensures fast query performance.

### 4. Data Validation
Schema validation at application level ensures data integrity.

## Security Best Practices

### 1. Connection Security
- Use MongoDB Atlas with SSL/TLS encryption
- Restrict network access to specific IPs
- Use strong database user passwords

### 2. Application Security
- Hash passwords with bcrypt
- Use JWT tokens for authentication
- Validate all input data
- Implement rate limiting

### 3. Environment Variables
- Never commit connection strings to version control
- Use environment variables for all sensitive data
- Rotate secrets regularly

## Monitoring and Maintenance

### 1. MongoDB Atlas Monitoring
- Built-in performance monitoring
- Real-time metrics and alerts
- Query performance insights

### 2. Backup Strategy
- MongoDB Atlas provides automatic backups
- Point-in-time recovery available
- Download backups for local storage

### 3. Scaling
- MongoDB Atlas auto-scaling
- Vertical and horizontal scaling options
- Performance optimization recommendations

## Troubleshooting

### Common Issues:

1. **Connection Timeout**
   - Check network access settings
   - Verify connection string format
   - Ensure database user has proper permissions

2. **Authentication Failed**
   - Verify username and password
   - Check database user permissions
   - Ensure correct database name

3. **Index Errors**
   - Duplicate key errors on unique indexes
   - Check for existing data conflicts
   - Drop and recreate indexes if needed

4. **Performance Issues**
   - Review query patterns
   - Check index usage
   - Monitor connection pool

### Debug Commands:
\`\`\`bash
# Test connection
node -e "const {MongoClient} = require('mongodb'); MongoClient.connect(process.env.MONGODB_URI).then(() => console.log('Connected')).catch(console.error)"

# Check collections
mongosh "your-connection-string" --eval "show collections"

# View indexes
mongosh "your-connection-string" --eval "db.appointments.getIndexes()"
\`\`\`

## Migration from MySQL

If migrating from MySQL:

1. **Data Export**: Export existing MySQL data
2. **Schema Mapping**: Map relational schema to document structure
3. **Data Import**: Import data into MongoDB collections
4. **Index Creation**: Create appropriate indexes
5. **Application Update**: Update application code to use MongoDB

---

**Your Medical Appointment Booking System is now ready with MongoDB! 🎉**
\`\`\`

Finally, let's update the Vercel configuration for MongoDB:
