# 🏥 MediBook - Medical Appointment Booking System

A complete full-stack web application for booking medical appointments with qualified doctors. Built for academic project requirements with modern web technologies.

## 🌟 Project Overview

**Team Project Requirements:**
- ✅ **6 Web Pages** - Complete medical booking system
- ✅ **Full-Stack Architecture** - Frontend + Backend + Database
- ✅ **CRUD Operations** - Create, Read, Update, Delete appointments
- ✅ **User Authentication** - Secure login/register system
- ✅ **Responsive Design** - Mobile-friendly Bootstrap-like styling
- ✅ **Team of 2-3 Students** - Organized codebase for collaboration

## 🎯 Live Demo

**Demo Credentials:**
- **Email:** `patient@demo.com`
- **Password:** `password123`

## 📱 Application Features

### 🏠 **Page 1: Home/Landing Page** (`/`)
- Beautiful hero section with call-to-action
- Features showcase with icons and descriptions
- Statistics section showing platform benefits
- Medical specializations overview
- How it works step-by-step guide
- Responsive footer with contact information

### 🔐 **Page 2: Login Page** (`/login`)
- Secure user authentication
- Password visibility toggle
- Demo credentials for testing
- Form validation and error handling
- Responsive design for all devices

### 📝 **Page 3: Register Page** (`/register`)
- User registration with validation
- Account type selection (Patient/Doctor)
- Password confirmation
- Real-time form validation
- Automatic login after registration

### 📊 **Page 4: Dashboard Page** (`/dashboard`)
- Personalized welcome message
- Appointment statistics cards
- Recent appointments overview
- Quick action buttons
- Available doctors preview
- Real-time data updates

### 📅 **Page 5: Book Appointment Page** (`/book-appointment`)
- Doctor selection with detailed profiles
- Date and time slot picker
- Symptoms description form
- Real-time availability checking
- Doctor information sidebar
- Appointment confirmation

### 📋 **Page 6: Appointments Page** (`/appointments`)
- Complete appointment history
- Search and filter functionality
- Status management (Scheduled/Completed/Cancelled)
- Appointment cancellation
- Detailed appointment information
- Summary statistics

## 🛠️ Technologies Used

### Frontend
- **Next.js 14** with App Router
- **TypeScript** for type safety
- **Tailwind CSS** for styling (Bootstrap-like classes)
- **Lucide React** for icons
- **Responsive Design** for all devices

### Backend
- **Next.js API Routes** (Node.js/Express.js equivalent)
- **RESTful API** design
- **JWT Authentication** with HTTP-only cookies
- **Input Validation** and error handling

### Database
- **In-memory storage** (simulated database)
- **8 Sample Doctors** with specializations
- **Demo appointments** for testing
- **CRUD operations** for all entities

### Security
- **Password validation** (minimum 8 characters)
- **Email validation** with regex
- **HTTP-only cookies** for session management
- **Input sanitization** and validation
- **CORS protection** for API routes

## 👥 Team Structure (2-3 Students)

### **Student 1: Backend Developer**
**Responsibilities:**
- API routes (`app/api/`)
- Authentication system (`lib/auth-context.tsx`)
- Data models and utilities (`lib/data.ts`)
- Database operations and validation

**Files to focus on:**
- `app/api/auth/login/route.ts`
- `app/api/auth/register/route.ts`
- `app/api/appointments/route.ts`
- `app/api/doctors/route.ts`
- `lib/auth-context.tsx`
- `lib/data.ts`

### **Student 2: Frontend Developer (Pages 1-3)**
**Responsibilities:**
- Home/Landing page
- Login page
- Register page
- Navigation component
- Basic styling and layout

**Files to focus on:**
- `app/page.tsx` (Home)
- `app/login/page.tsx`
- `app/register/page.tsx`
- `components/navigation.tsx`
- `app/globals.css`

### **Student 3: Frontend Developer (Pages 4-6)**
**Responsibilities:**
- Dashboard page
- Book appointment page
- Appointments management page
- Advanced JavaScript functionality
- API integration

**Files to focus on:**
- `app/dashboard/page.tsx`
- `app/book-appointment/page.tsx`
- `app/appointments/page.tsx`
- API integration and state management

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ installed
- Git for version control
- Code editor (VS Code recommended)

### Installation
1. **Clone the repository**
   \`\`\`bash
   git clone <your-repo-url>
   cd medical-appointment-system
   \`\`\`

2. **Install dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Set up environment variables**
   \`\`\`bash
   cp .env.example .env.local
   \`\`\`

4. **Start development server**
   \`\`\`bash
   npm run dev
   \`\`\`

5. **Open in browser**
   \`\`\`
   http://localhost:3000
   \`\`\`

## 🧪 Testing the Application

### Demo Account
Use these credentials to test all features:
- **Email:** `patient@demo.com`
- **Password:** `password123`

### Test Scenarios
1. **Registration:** Create a new account
2. **Login:** Sign in with demo credentials
3. **Dashboard:** View appointment statistics
4. **Book Appointment:** Schedule with any doctor
5. **View Appointments:** Check appointment history
6. **Cancel Appointment:** Cancel a scheduled appointment

## 📊 Sample Data

### 8 Available Doctors
1. **Dr. John Smith** - Cardiology ($150)
2. **Dr. Sarah Johnson** - Dermatology ($120)
3. **Dr. Michael Brown** - Orthopedics ($180)
4. **Dr. Emily Davis** - Pediatrics ($100)
5. **Dr. Robert Wilson** - Neurology ($200)
6. **Dr. Lisa Anderson** - Gynecology ($140)
7. **Dr. David Martinez** - Psychiatry ($160)
8. **Dr. Jennifer Lee** - Ophthalmology ($130)

### Demo Appointments
The demo account includes:
- 1 upcoming appointment (Cardiology)
- 1 scheduled appointment (Pediatrics)
- 1 completed appointment (Dermatology)

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration
- `POST /api/auth/logout` - User logout

### Doctors
- `GET /api/doctors` - Get all doctors

### Appointments
- `GET /api/appointments` - Get user appointments
- `POST /api/appointments` - Book new appointment
- `PATCH /api/appointments/[id]/cancel` - Cancel appointment

### Health Check
- `GET /api/health` - Application health status

## 🎨 Design System

### Colors
- **Primary:** Blue (#007bff)
- **Success:** Green (#28a745)
- **Danger:** Red (#dc3545)
- **Warning:** Yellow (#ffc107)
- **Gray:** Various shades for text and backgrounds

### Components
- **Cards:** Rounded corners with shadow
- **Buttons:** Multiple variants (primary, outline, etc.)
- **Forms:** Consistent styling with validation
- **Badges:** Status indicators
- **Navigation:** Responsive with mobile menu

## 📱 Responsive Design

- **Mobile First:** Optimized for mobile devices
- **Tablet Support:** Adapted layouts for tablets
- **Desktop:** Full-featured desktop experience
- **Breakpoints:** Standard responsive breakpoints

## 🔒 Security Features

- **Input Validation:** All forms validated
- **Password Security:** Minimum 8 characters
- **Session Management:** HTTP-only cookies
- **CORS Protection:** API route protection
- **Error Handling:** Graceful error messages

## 🚀 Deployment Options

### Vercel (Recommended)
1. Connect GitHub repository
2. Set environment variables
3. Deploy automatically

### Other Platforms
- **Netlify:** Static site deployment
- **Railway:** Full-stack deployment with database
- **Heroku:** Container-based deployment

## 📚 Learning Outcomes

### Technical Skills
- **Full-Stack Development:** Frontend + Backend integration
- **API Design:** RESTful API development
- **Database Operations:** CRUD operations
- **Authentication:** Secure user management
- **Responsive Design:** Mobile-first development
- **State Management:** React hooks and context
- **TypeScript:** Type-safe development

### Project Management
- **Team Collaboration:** Git workflow and code organization
- **Code Structure:** Modular and maintainable codebase
- **Documentation:** Comprehensive project documentation
- **Testing:** Manual testing and validation
- **Deployment:** Production deployment process

## 🐛 Troubleshooting

### Common Issues

1. **Login Not Working**
   - Check demo credentials: `patient@demo.com` / `password123`
   - Clear browser cookies and try again
   - Ensure JavaScript is enabled

2. **Appointments Not Loading**
   - Check browser console for errors
   - Refresh the page
   - Try logging out and back in

3. **Booking Fails**
   - Ensure all fields are filled
   - Check date is not in the past
   - Verify symptoms are at least 10 characters

4. **Styling Issues**
   - Clear browser cache
   - Check if CSS is loading properly
   - Try different browser

### Development Issues

1. **npm install fails**
   \`\`\`bash
   rm -rf node_modules package-lock.json
   npm install
   \`\`\`

2. **Port already in use**
   \`\`\`bash
   npx kill-port 3000
   npm run dev
   \`\`\`

3. **TypeScript errors**
   \`\`\`bash
   npm run type-check
   \`\`\`

## 📈 Future Enhancements

### Phase 2 Features
- **Email Notifications:** Appointment reminders
- **Payment Integration:** Online payment processing
- **Video Consultations:** Telemedicine support
- **Medical Records:** Patient history management
- **Prescription Management:** Digital prescriptions
- **Multi-language Support:** Internationalization

### Technical Improvements
- **Real Database:** PostgreSQL or MongoDB
- **File Uploads:** Profile pictures and documents
- **Push Notifications:** Real-time updates
- **Advanced Search:** Elasticsearch integration
- **Analytics Dashboard:** Usage statistics
- **Mobile App:** React Native version

## 🏆 Project Submission

### Deliverables
1. **Source Code:** Complete GitHub repository
2. **Live Demo:** Deployed application URL
3. **Documentation:** This README file
4. **Presentation:** Demo video or slides
5. **Team Report:** Individual contributions

### Grading Criteria
- **Functionality:** All features working correctly
- **Code Quality:** Clean, organized, and documented
- **User Experience:** Intuitive and responsive design
- **Team Collaboration:** Equal contribution from all members
- **Innovation:** Creative features and solutions

## 📞 Support

### Getting Help
- **GitHub Issues:** Report bugs and request features
- **Team Communication:** Use Discord/Slack for coordination
- **Code Reviews:** Regular peer reviews
- **Documentation:** Refer to this README for guidance

### Resources
- **Next.js Documentation:** [nextjs.org/docs](https://nextjs.org/docs)
- **Tailwind CSS:** [tailwindcss.com/docs](https://tailwindcss.com/docs)
- **TypeScript:** [typescriptlang.org/docs](https://typescriptlang.org/docs)
- **React Hooks:** [react.dev/reference/react](https://react.dev/reference/react)

## 🎉 Conclusion

**Congratulations!** You now have a complete, production-ready Medical Appointment Booking System that demonstrates:

✅ **Full-Stack Development** with modern technologies  
✅ **6 Complete Web Pages** with all required functionality  
✅ **CRUD Operations** for appointments and user management  
✅ **Responsive Design** that works on all devices  
✅ **Team-Ready Codebase** organized for collaboration  
✅ **Professional Documentation** for easy understanding  

This project showcases real-world development skills and provides an excellent foundation for your academic submission and future portfolio.

**Good luck with your presentation! 🚀**

---

**Built with ❤️ by the MediBook Development Team**  
*Academic Project - 2024*
