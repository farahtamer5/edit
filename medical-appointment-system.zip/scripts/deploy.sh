#!/bin/bash

# Medical Appointment Booking System - Deployment Script

echo "🏥 Medical Appointment Booking System - Deployment Script"
echo "========================================================="

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first."
    exit 1
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm first."
    exit 1
fi

echo "✅ Node.js and npm are installed"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed successfully"

# Check if .env file exists
if [ ! -f .env ]; then
    echo "⚠️  .env file not found. Creating from .env.example..."
    cp .env.example .env
    echo "📝 Please edit .env file with your database credentials"
    echo "🔧 Required variables: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME, JWT_SECRET"
fi

# Initialize database
echo "🗄️  Initializing database..."
npm run init-db

if [ $? -ne 0 ]; then
    echo "❌ Database initialization failed"
    echo "🔧 Please check your database credentials in .env file"
    exit 1
fi

echo "✅ Database initialized successfully"

# Start the application
echo "🚀 Starting the application..."
echo "📱 Application will be available at: http://localhost:${PORT:-3000}"
echo "🛑 Press Ctrl+C to stop the server"

npm start
