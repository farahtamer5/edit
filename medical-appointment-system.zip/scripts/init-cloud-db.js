const mysql = require("mysql2/promise")
require("dotenv").config()

const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
}

async function initializeCloudDatabase() {
  console.log("🏥 Initializing Medical Appointment Booking Database...")
  console.log("================================================")

  let connection
  try {
    connection = await mysql.createConnection(dbConfig)
    console.log("✅ Connected to database")

    // Create tables
    console.log("📋 Creating tables...")

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(15),
        role ENUM('patient', 'doctor', 'admin') DEFAULT 'patient',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_email (email),
        INDEX idx_role (role)
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS doctors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        specialization VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(15),
        available_days VARCHAR(50),
        available_hours VARCHAR(50),
        consultation_fee DECIMAL(10,2) DEFAULT 0.00,
        experience_years INT DEFAULT 0,
        qualification VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_specialization (specialization),
        INDEX idx_email (email)
      )
    `)

    await connection.execute(`
      CREATE TABLE IF NOT EXISTS appointments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT NOT NULL,
        doctor_id INT NOT NULL,
        appointment_date DATE NOT NULL,
        appointment_time TIME NOT NULL,
        status ENUM('scheduled', 'completed', 'cancelled', 'rescheduled') DEFAULT 'scheduled',
        symptoms TEXT,
        diagnosis TEXT,
        prescription TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
        INDEX idx_patient_id (patient_id),
        INDEX idx_doctor_id (doctor_id),
        INDEX idx_appointment_date (appointment_date),
        INDEX idx_status (status),
        UNIQUE KEY unique_appointment (doctor_id, appointment_date, appointment_time)
      )
    `)

    console.log("✅ Tables created successfully")

    // Check if doctors exist
    const [existingDoctors] = await connection.execute("SELECT COUNT(*) as count FROM doctors")
    if (existingDoctors[0].count === 0) {
      console.log("👨‍⚕️ Seeding doctors data...")

      const doctors = [
        [
          "John Smith",
          "Cardiology",
          "john.smith@hospital.com",
          "123-456-7890",
          "Monday,Tuesday,Wednesday,Thursday,Friday",
          "09:00-17:00",
          150.0,
          15,
          "MD, FACC - Harvard Medical School",
        ],
        [
          "Sarah Johnson",
          "Dermatology",
          "sarah.johnson@hospital.com",
          "123-456-7891",
          "Monday,Wednesday,Friday",
          "10:00-16:00",
          120.0,
          12,
          "MD, Dermatology - Johns Hopkins University",
        ],
        [
          "Michael Brown",
          "Orthopedics",
          "michael.brown@hospital.com",
          "123-456-7892",
          "Tuesday,Thursday,Saturday",
          "08:00-14:00",
          180.0,
          18,
          "MD, Orthopedic Surgery - Mayo Clinic",
        ],
        [
          "Emily Davis",
          "Pediatrics",
          "emily.davis@hospital.com",
          "123-456-7893",
          "Monday,Tuesday,Wednesday,Thursday,Friday",
          "09:00-17:00",
          100.0,
          10,
          "MD, Pediatrics - Stanford University",
        ],
        [
          "Robert Wilson",
          "Neurology",
          "robert.wilson@hospital.com",
          "123-456-7894",
          "Monday,Wednesday,Friday",
          "11:00-18:00",
          200.0,
          20,
          "MD, PhD, Neurology - UCLA Medical Center",
        ],
        [
          "Lisa Anderson",
          "Gynecology",
          "lisa.anderson@hospital.com",
          "123-456-7895",
          "Tuesday,Thursday,Friday",
          "09:00-15:00",
          140.0,
          14,
          "MD, OB/GYN - Columbia University",
        ],
        [
          "David Martinez",
          "Psychiatry",
          "david.martinez@hospital.com",
          "123-456-7896",
          "Monday,Tuesday,Wednesday,Thursday",
          "10:00-18:00",
          160.0,
          16,
          "MD, Psychiatry - Yale School of Medicine",
        ],
        [
          "Jennifer Lee",
          "Ophthalmology",
          "jennifer.lee@hospital.com",
          "123-456-7897",
          "Monday,Wednesday,Friday,Saturday",
          "08:00-16:00",
          130.0,
          11,
          "MD, Ophthalmology - University of Pennsylvania",
        ],
      ]

      for (const doctor of doctors) {
        await connection.execute(
          "INSERT INTO doctors (name, specialization, email, phone, available_days, available_hours, consultation_fee, experience_years, qualification) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
          doctor,
        )
      }

      console.log("✅ Doctors data seeded successfully")
    } else {
      console.log("ℹ️  Doctors data already exists")
    }

    console.log("🎉 Database initialization completed successfully!")
    console.log("📊 Database Statistics:")

    const [userCount] = await connection.execute("SELECT COUNT(*) as count FROM users")
    const [doctorCount] = await connection.execute("SELECT COUNT(*) as count FROM doctors")
    const [appointmentCount] = await connection.execute("SELECT COUNT(*) as count FROM appointments")

    console.log(`   Users: ${userCount[0].count}`)
    console.log(`   Doctors: ${doctorCount[0].count}`)
    console.log(`   Appointments: ${appointmentCount[0].count}`)
  } catch (error) {
    console.error("❌ Database initialization failed:", error)
    throw error
  } finally {
    if (connection) {
      await connection.end()
      console.log("🔌 Database connection closed")
    }
  }
}

// Run if called directly
if (require.main === module) {
  initializeCloudDatabase()
    .then(() => {
      console.log("✅ Script completed successfully")
      process.exit(0)
    })
    .catch((error) => {
      console.error("❌ Script failed:", error)
      process.exit(1)
    })
}

module.exports = { initializeCloudDatabase }
