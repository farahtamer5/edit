const mysql = require("mysql2/promise")
require("dotenv").config()

const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
}

async function createDatabase() {
  let connection
  try {
    // Connect without specifying database
    connection = await mysql.createConnection(dbConfig)

    // Create database if it doesn't exist
    await connection.execute(`CREATE DATABASE IF NOT EXISTS ${process.env.DB_NAME || "medical_booking"}`)
    console.log("Database created successfully")

    await connection.end()
  } catch (error) {
    console.error("Error creating database:", error)
    if (connection) await connection.end()
    throw error
  }
}

async function createTables() {
  let connection
  try {
    connection = await mysql.createConnection({
      ...dbConfig,
      database: process.env.DB_NAME || "medical_booking",
    })

    // Create users table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        phone VARCHAR(15),
        role ENUM('patient', 'doctor', 'admin') DEFAULT 'patient',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_email (email),
        INDEX idx_role (role)
      )
    `)

    // Create doctors table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS doctors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        specialization VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        phone VARCHAR(15),
        available_days VARCHAR(50),
        available_hours VARCHAR(50),
        consultation_fee DECIMAL(10,2) DEFAULT 0.00,
        experience_years INT DEFAULT 0,
        qualification VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_specialization (specialization),
        INDEX idx_email (email)
      )
    `)

    // Create appointments table
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS appointments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT NOT NULL,
        doctor_id INT NOT NULL,
        appointment_date DATE NOT NULL,
        appointment_time TIME NOT NULL,
        status ENUM('scheduled', 'completed', 'cancelled', 'rescheduled') DEFAULT 'scheduled',
        symptoms TEXT,
        diagnosis TEXT,
        prescription TEXT,
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
        INDEX idx_patient_id (patient_id),
        INDEX idx_doctor_id (doctor_id),
        INDEX idx_appointment_date (appointment_date),
        INDEX idx_status (status),
        UNIQUE KEY unique_appointment (doctor_id, appointment_date, appointment_time)
      )
    `)

    // Create appointment_history table for tracking changes
    await connection.execute(`
      CREATE TABLE IF NOT EXISTS appointment_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        appointment_id INT NOT NULL,
        action ENUM('created', 'updated', 'cancelled', 'completed') NOT NULL,
        old_values JSON,
        new_values JSON,
        changed_by INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE,
        FOREIGN KEY (changed_by) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_appointment_id (appointment_id)
      )
    `)

    console.log("All tables created successfully")
    await connection.end()
  } catch (error) {
    console.error("Error creating tables:", error)
    if (connection) await connection.end()
    throw error
  }
}

async function seedDatabase() {
  let connection
  try {
    connection = await mysql.createConnection({
      ...dbConfig,
      database: process.env.DB_NAME || "medical_booking",
    })

    // Check if doctors already exist
    const [existingDoctors] = await connection.execute("SELECT COUNT(*) as count FROM doctors")
    if (existingDoctors[0].count > 0) {
      console.log("Database already seeded")
      await connection.end()
      return
    }

    // Insert sample doctors
    const doctors = [
      {
        name: "John Smith",
        specialization: "Cardiology",
        email: "john.smith@hospital.com",
        phone: "123-456-7890",
        available_days: "Monday,Tuesday,Wednesday,Thursday,Friday",
        available_hours: "09:00-17:00",
        consultation_fee: 150.0,
        experience_years: 15,
        qualification: "MD, FACC - Harvard Medical School",
      },
      {
        name: "Sarah Johnson",
        specialization: "Dermatology",
        email: "sarah.johnson@hospital.com",
        phone: "123-456-7891",
        available_days: "Monday,Wednesday,Friday",
        available_hours: "10:00-16:00",
        consultation_fee: 120.0,
        experience_years: 12,
        qualification: "MD, Dermatology - Johns Hopkins University",
      },
      {
        name: "Michael Brown",
        specialization: "Orthopedics",
        email: "michael.brown@hospital.com",
        phone: "123-456-7892",
        available_days: "Tuesday,Thursday,Saturday",
        available_hours: "08:00-14:00",
        consultation_fee: 180.0,
        experience_years: 18,
        qualification: "MD, Orthopedic Surgery - Mayo Clinic",
      },
      {
        name: "Emily Davis",
        specialization: "Pediatrics",
        email: "emily.davis@hospital.com",
        phone: "123-456-7893",
        available_days: "Monday,Tuesday,Wednesday,Thursday,Friday",
        available_hours: "09:00-17:00",
        consultation_fee: 100.0,
        experience_years: 10,
        qualification: "MD, Pediatrics - Stanford University",
      },
      {
        name: "Robert Wilson",
        specialization: "Neurology",
        email: "robert.wilson@hospital.com",
        phone: "123-456-7894",
        available_days: "Monday,Wednesday,Friday",
        available_hours: "11:00-18:00",
        consultation_fee: 200.0,
        experience_years: 20,
        qualification: "MD, PhD, Neurology - UCLA Medical Center",
      },
      {
        name: "Lisa Anderson",
        specialization: "Gynecology",
        email: "lisa.anderson@hospital.com",
        phone: "123-456-7895",
        available_days: "Tuesday,Thursday,Friday",
        available_hours: "09:00-15:00",
        consultation_fee: 140.0,
        experience_years: 14,
        qualification: "MD, OB/GYN - Columbia University",
      },
      {
        name: "David Martinez",
        specialization: "Psychiatry",
        email: "david.martinez@hospital.com",
        phone: "123-456-7896",
        available_days: "Monday,Tuesday,Wednesday,Thursday",
        available_hours: "10:00-18:00",
        consultation_fee: 160.0,
        experience_years: 16,
        qualification: "MD, Psychiatry - Yale School of Medicine",
      },
      {
        name: "Jennifer Lee",
        specialization: "Ophthalmology",
        email: "jennifer.lee@hospital.com",
        phone: "123-456-7897",
        available_days: "Monday,Wednesday,Friday,Saturday",
        available_hours: "08:00-16:00",
        consultation_fee: 130.0,
        experience_years: 11,
        qualification: "MD, Ophthalmology - University of Pennsylvania",
      },
    ]

    for (const doctor of doctors) {
      await connection.execute(
        `
        INSERT INTO doctors (name, specialization, email, phone, available_days, available_hours, consultation_fee, experience_years, qualification)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
        [
          doctor.name,
          doctor.specialization,
          doctor.email,
          doctor.phone,
          doctor.available_days,
          doctor.available_hours,
          doctor.consultation_fee,
          doctor.experience_years,
          doctor.qualification,
        ],
      )
    }

    console.log("Database seeded with sample doctors")
    await connection.end()
  } catch (error) {
    console.error("Error seeding database:", error)
    if (connection) await connection.end()
    throw error
  }
}

module.exports = {
  createDatabase,
  createTables,
  seedDatabase,
}

// Run if called directly
if (require.main === module) {
  async function init() {
    try {
      await createDatabase()
      await createTables()
      await seedDatabase()
      console.log("Database initialization completed successfully")
      process.exit(0)
    } catch (error) {
      console.error("Database initialization failed:", error)
      process.exit(1)
    }
  }

  init()
}
