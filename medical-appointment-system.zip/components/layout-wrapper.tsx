"use client"

import type React from "react"

import { AuthProvider } from "@/lib/auth-context"
import Navigation from "./navigation"

export default function LayoutWrapper({ children }: { children: React.ReactNode }) {
  return (
    <AuthProvider>
      <div className="min-h-screen bg-gray-50">
        <Navigation />
        <main>{children}</main>
      </div>
    </AuthProvider>
  )
}
