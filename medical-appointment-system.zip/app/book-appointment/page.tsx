"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/lib/auth-context"
import { ArrowLeft, Calendar, Clock, User, Stethoscope, DollarSign } from "lucide-react"
import Link from "next/link"
import LayoutWrapper from "@/components/layout-wrapper"
import { timeSlots, type Doctor } from "@/lib/data"

export default function BookAppointmentPage() {
  const { user } = useAuth()
  const router = useRouter()
  const [doctors, setDoctors] = useState<Doctor[]>([])
  const [formData, setFormData] = useState({
    doctorId: "",
    appointmentDate: "",
    appointmentTime: "",
    symptoms: "",
  })
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [loading, setLoading] = useState(false)
  const [selectedDoctor, setSelectedDoctor] = useState<Doctor | null>(null)

  useEffect(() => {
    if (!user) {
      router.push("/login")
      return
    }

    fetchDoctors()
  }, [user, router])

  useEffect(() => {
    if (formData.doctorId) {
      const doctor = doctors.find((d) => d.id === formData.doctorId)
      setSelectedDoctor(doctor || null)
    } else {
      setSelectedDoctor(null)
    }
  }, [formData.doctorId, doctors])

  const fetchDoctors = async () => {
    try {
      const response = await fetch("/api/doctors")
      if (response.ok) {
        const data = await response.json()
        setDoctors(data)
      }
    } catch (error) {
      console.error("Failed to fetch doctors:", error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!formData.doctorId || !formData.appointmentDate || !formData.appointmentTime || !formData.symptoms) {
      setError("Please fill in all required fields")
      return
    }

    // Validate appointment date
    const appointmentDate = new Date(formData.appointmentDate)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (appointmentDate < today) {
      setError("Appointment date cannot be in the past")
      return
    }

    if (formData.symptoms.length < 10) {
      setError("Please provide more details about your symptoms (minimum 10 characters)")
      return
    }

    setLoading(true)

    try {
      const response = await fetch("/api/appointments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          doctor_id: formData.doctorId,
          appointment_date: formData.appointmentDate,
          appointment_time: formData.appointmentTime,
          symptoms: formData.symptoms,
        }),
      })

      const data = await response.json()

      if (response.ok) {
        setSuccess("Appointment booked successfully! Redirecting to dashboard...")
        setTimeout(() => {
          router.push("/dashboard")
        }, 2000)
      } else {
        setError(data.error || "Failed to book appointment")
      }
    } catch (error) {
      setError("Network error. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return null
  }

  // Get minimum date (today)
  const today = new Date().toISOString().split("T")[0]

  return (
    <LayoutWrapper>
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="mb-8">
            <Link href="/dashboard" className="btn btn-outline-primary mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Link>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">Book New Appointment</h1>
            <p className="text-gray-600">Schedule an appointment with one of our qualified doctors</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Booking Form */}
            <div className="lg:col-span-2">
              <div className="card">
                <div className="card-header">
                  <h2 className="text-xl font-semibold text-gray-800">Appointment Details</h2>
                </div>
                <div className="card-body">
                  {error && <div className="alert alert-danger mb-6">{error}</div>}

                  {success && <div className="alert alert-success mb-6">{success}</div>}

                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div>
                      <label htmlFor="doctor" className="block text-sm font-medium text-gray-700 mb-2">
                        Select Doctor *
                      </label>
                      <select
                        id="doctor"
                        className="form-select"
                        value={formData.doctorId}
                        onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                        required
                      >
                        <option value="">Choose a doctor</option>
                        {doctors.map((doctor) => (
                          <option key={doctor.id} value={doctor.id}>
                            Dr. {doctor.name} - {doctor.specialization} (${doctor.consultationFee})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor="date" className="block text-sm font-medium text-gray-700 mb-2">
                          Appointment Date *
                        </label>
                        <div className="relative">
                          <input
                            id="date"
                            type="date"
                            className="form-control pl-10"
                            value={formData.appointmentDate}
                            onChange={(e) => setFormData({ ...formData, appointmentDate: e.target.value })}
                            min={today}
                            required
                          />
                          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                      </div>

                      <div>
                        <label htmlFor="time" className="block text-sm font-medium text-gray-700 mb-2">
                          Appointment Time *
                        </label>
                        <div className="relative">
                          <select
                            id="time"
                            className="form-select pl-10"
                            value={formData.appointmentTime}
                            onChange={(e) => setFormData({ ...formData, appointmentTime: e.target.value })}
                            required
                          >
                            <option value="">Choose a time slot</option>
                            {timeSlots.map((time) => (
                              <option key={time} value={time}>
                                {time}
                              </option>
                            ))}
                          </select>
                          <Clock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                        </div>
                      </div>
                    </div>

                    <div>
                      <label htmlFor="symptoms" className="block text-sm font-medium text-gray-700 mb-2">
                        Symptoms / Reason for Visit *
                      </label>
                      <textarea
                        id="symptoms"
                        rows={4}
                        className="form-control"
                        placeholder="Please describe your symptoms or reason for the appointment in detail..."
                        value={formData.symptoms}
                        onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
                        required
                      />
                      <p className="text-sm text-gray-500 mt-1">
                        {formData.symptoms.length}/10 characters minimum required
                      </p>
                    </div>

                    <button
                      type="submit"
                      disabled={loading || formData.symptoms.length < 10}
                      className="btn btn-primary w-full"
                    >
                      {loading ? (
                        <>
                          <span className="spinner mr-2"></span>
                          Booking Appointment...
                        </>
                      ) : (
                        <>
                          <Calendar className="w-4 h-4 mr-2" />
                          Book Appointment
                        </>
                      )}
                    </button>
                  </form>
                </div>
              </div>
            </div>

            {/* Doctor Information Sidebar */}
            <div className="lg:col-span-1">
              {selectedDoctor ? (
                <div className="card">
                  <div className="card-header">
                    <h3 className="text-lg font-semibold text-gray-800">Doctor Information</h3>
                  </div>
                  <div className="card-body">
                    <div className="text-center mb-6">
                      <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                        <User className="w-10 h-10 text-blue-600" />
                      </div>
                      <h4 className="text-xl font-semibold text-gray-800">Dr. {selectedDoctor.name}</h4>
                      <p className="text-gray-600">{selectedDoctor.specialization}</p>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center gap-3">
                        <Stethoscope className="w-5 h-5 text-gray-400" />
                        <div>
                          <p className="text-sm font-medium text-gray-700">Experience</p>
                          <p className="text-sm text-gray-600">{selectedDoctor.experienceYears} years</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <DollarSign className="w-5 h-5 text-gray-400" />
                        <div>
                          <p className="text-sm font-medium text-gray-700">Consultation Fee</p>
                          <p className="text-sm text-gray-600">${selectedDoctor.consultationFee}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-gray-700">Available Days</p>
                          <p className="text-sm text-gray-600">{selectedDoctor.availableDays.join(", ")}</p>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        <Clock className="w-5 h-5 text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-gray-700">Available Hours</p>
                          <p className="text-sm text-gray-600">{selectedDoctor.availableHours}</p>
                        </div>
                      </div>
                    </div>

                    <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                      <h5 className="text-sm font-medium text-blue-800 mb-2">Qualification</h5>
                      <p className="text-sm text-blue-700">{selectedDoctor.qualification}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="card">
                  <div className="card-body text-center py-12">
                    <User className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-800 mb-2">Select a Doctor</h3>
                    <p className="text-gray-600">Choose a doctor from the dropdown to see their information</p>
                  </div>
                </div>
              )}

              {/* Available Doctors List */}
              <div className="card mt-6">
                <div className="card-header">
                  <h3 className="text-lg font-semibold text-gray-800">All Available Doctors</h3>
                </div>
                <div className="card-body">
                  <div className="space-y-3">
                    {doctors.map((doctor) => (
                      <div
                        key={doctor.id}
                        className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                          formData.doctorId === doctor.id
                            ? "border-blue-500 bg-blue-50"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                        onClick={() => setFormData({ ...formData, doctorId: doctor.id })}
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <User className="w-5 h-5 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-gray-800">Dr. {doctor.name}</h4>
                            <p className="text-xs text-gray-600">{doctor.specialization}</p>
                            <p className="text-xs text-blue-600 font-medium">${doctor.consultationFee}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </LayoutWrapper>
  )
}
