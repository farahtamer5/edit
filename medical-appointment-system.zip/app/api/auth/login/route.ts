import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Demo login
    if (email === "patient@demo.com" && password === "password123") {
      const response = NextResponse.json({
        success: true,
        user: {
          id: "demo-patient-1",
          name: "Demo Patient",
          email: "patient@demo.com",
          role: "patient",
        },
      })

      response.cookies.set("auth-token", "demo-token", {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 86400,
      })

      return response
    }

    // Additional users for demo
    const users = [
      { email: "john@example.com", password: "password123", name: "John Doe", id: "user-1" },
      { email: "jane@example.com", password: "password123", name: "Jane Smith", id: "user-2" },
    ]

    const user = users.find((u) => u.email === email && u.password === password)

    if (user) {
      const response = NextResponse.json({
        success: true,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: "patient",
        },
      })

      response.cookies.set("auth-token", `user-${user.id}`, {
        httpOnly: true,
        secure: process.env.NODE_ENV === "production",
        sameSite: "strict",
        maxAge: 86400,
      })

      return response
    }

    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
  } catch (error) {
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
